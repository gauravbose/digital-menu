from django.db import models


class DebugObject(models.Model):
    pass
