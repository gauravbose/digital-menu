from django.db import models


class NiceModel(models.Model):
    pass
